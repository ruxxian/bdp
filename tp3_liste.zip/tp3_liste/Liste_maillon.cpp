#include "Liste_maillon.hpp"
#include <cstddef>

//1
liste::liste()
{
	tete=NULL;
}

//2
maillon::maillon(int x=0)
{
	info=x;
	suiv=NULL;
}

//3
void liste::ajoute(int x=0)
{
	maillon * a = new maillon(x);
	maillon *pr, *c;
	pr=NULL;c=tete;
	while(c)
		{
		pr=c;
		c=(*c).suiv;
		}
	if(!pr)tete = a;
	else (*pr).suiv = a;
}
liste::liste(int * T, int size)
{
	tete=NULL;
	for(int i=0; i<size; ++i)
	{
		ajoute(T[i]);
	}
}

//4
void liste::afficher()
{
	maillon* c = tete;
	while(c)
	{
		cout<<(*c).info<<" ";
		c = (*c).suiv;
	}
	cout << endl;
}

/*5
liste::~liste()
{
	maillon* p = tete, *s;
	while(p)
	{
		s = (*p).suiv;
		delete p;
		p = s;
	}
}*/
maillon::~maillon()
{
if(suiv)delete suiv;
}

liste::~liste()
{
if(tete)delete tete;
}

//6
void liste::afficher_rec(maillon* p)
{
	if(!p)return;
	cout<<(*p).info<<" ";
	afficher_rec((*p).suiv);
}
void liste::afficher_rec()
{
	afficher_rec(tete);
}

//7
void liste::afficher_rec_inverse(maillon *p)
{
        if(!p)return;
        afficher_rec_inverse((*p).suiv);
	cout<<(*p).info<<" ";
}

//8
int liste::cardinale()
{
	int compt = 0;
        maillon* c = tete;
        while(c)
        {
		compt++;
                c = (*c).suiv;
        }
	return compt;
}

//9
bool liste::chercher(int x)
{
	maillon* c = tete;
	while(c)
	{
		if((*c).info == x)return true;
		c = (*c).suiv;
	}
	return false;
}
//10
bool liste::chercher2(int x)
{
        maillon* c = tete;
        while(c && (*c).info<x )
        {
                c = (*c).suiv;
        }
        return (*c).info == x;
}

//11
int liste::Nb_occurence(int x)
{
	int cpt=0;
	maillon* c = tete;
	while(c)
	{
		if((*c).info == x)cpt++;
	}
	return cpt;
}

//12
bool liste::supprimer(int x)
{
maillon* p = tete, *pr;
while(p)
{
	if((*p).info == x)break;
	pr = p;p = (*p).suiv;
}
if(p==NULL)return false;
if(pr=NULL)
{
	maillon* q = tete;
	tete = (*tete).suiv;
	(*q).suiv = NULL;
	delete q;
	return true;
}
maillon *q = (*pr).suiv;
(*pr).suiv = (*p).suiv;
(*q).suiv = NULL;
delete q;
return true;
}

//13
void liste::supprimer_tout()
{
//bordel comment je fait ???????????????
}

