#include <iostream>
using namespace std;


class maillon
{
friend class liste;
int info;
maillon * suiv;
	public:
maillon(int x);
~maillon();
void afficher();
};



class liste
{
maillon * tete;
	public:
liste();
liste(int * T, int size);
liste(const liste & L);
~liste();

void ajoute(int x);
void afficher();
void afficher_rec();
void afficher_rec(maillon* p);
void afficher_rec_inverse();
void afficher_rec_inverse(maillon *p);
int cardinale();
bool chercher(int x);
bool chercher2(int x);
int Nb_occurence(int x);
bool supprimer(int x);
void supprimer_tout();
void outils_pour_Recherche (int x, Maillon * & courant, Maillon * & precedent, Maillon * & avant_precedent);
};

