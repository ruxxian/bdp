#include "Liste_rapide.hpp"

lister::lister(int size)
{
size_p=size;
nbe=0;
princ = new liste();
second = new liste();
}

~lister()
{

}

bool lister::chercher(int n)
{
	maillon *c, *pr, *apr;

	(*princ).outils_pour_Recherche(n, c, pr, apr);
	if(c)
		if(pr == NULL)return true;
		if(apr)
		{
			(*apr).suiv = c;
			(*pr).suiv = (*c).suiv;
			(*c).suiv = pr;
			return true;
		}
		else
		{
			(*pr).suiv = (*c).suiv;
			(*c).suiv = pr;
		}
	}
	else
	{
		(*second).outils_pour_Recherche(n, c, pr, apr);
		if(c)
		{
			if(nbe<size_p)
			{
				//il faut deplacer le mailon dans la premiere liste en bougeant les adresses
			}
			
		}
	}
}

void lister::inserer(maillon *p)
{

	if(nbe<size_p)
	{

	}
}


bool lister::supprimer(int n)
{

}

V• Si l’élément est le premier élément de la première liste alors il restera à sa place.
V• Si l’élément est dans la première première liste mais n’est pas le premier alors il change
de place avec son précédent.

• Si l’élément est dans la seconde liste alors il est déplacé en queue de la première liste.
• Les nouveaux éléments sont ajoutés à la tête de la première liste.
• Si la première liste dépasse sa capacité maximale alors son dernier élément est
déplacé à la tête de la seconde liste.
• S’il y a des places disponibles dans la première liste alors des éléments de la liste
secondaire (se trouvant en tête de liste) sont déplacés vers la queue de la liste
principale.
