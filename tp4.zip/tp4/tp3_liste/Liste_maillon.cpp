#include "Liste_maillon.hpp"
#include <cstddef>

//1
liste::liste()
{
	tete=NULL;
}

//2
maillon::maillon(int x=0)
{
	info=x;
	suiv=NULL;
}

void maillon::afficher(){cout<<info<<endl;}

//3
void liste::ajoute(int x=0)
{
	maillon * a = new maillon(x);
	maillon *pr, *c;
	pr=NULL;c=tete;
	while(c)
		{
		pr=c;
		c=(*c).suiv;
		}
	if(!pr)tete = a;
	else (*pr).suiv = a;
}
liste::liste(int * T, int size)
{
	tete=NULL;
	for(int i=0; i<size; ++i)
	{
		ajoute(T[i]);
	}
}

//4
void liste::afficher()
{
	maillon* c = tete;
	if(!c)cout << "liste vide";
	while(c)
	{
		cout<<(*c).info<<" ";
		c = (*c).suiv;
	}
	cout << endl;
}

//5
/*
liste::~liste()
{
	maillon* p = tete, *s;
	while(p)
	{
		s = (*p).suiv;
		delete p;
		p = s;
	}
}*/
maillon::~maillon()
{
if(suiv)delete suiv;
}

liste::~liste()
{
if(tete)delete tete;
}

//6
void liste::afficher_rec(maillon* p)
{
	if(!p)return;
	cout<<(*p).info<<" ";
	afficher_rec((*p).suiv);
}
void liste::afficher_rec()
{
	afficher_rec(tete);
	cout << endl;
}

//7
void liste::afficher_rec_inverse(maillon *p)
{
        if(!p)return;
        afficher_rec_inverse((*p).suiv);
	cout<<(*p).info<<" ";
}
void liste::afficher_rec_inverse()
{
	afficher_rec_inverse(tete);
	cout << endl;
}

//8
int liste::cardinale()
{
	int compt = 0;
        maillon* c = tete;
        while(c)
        {
		compt++;
                c = (*c).suiv;
        }
	return compt;
}

//9
bool liste::chercher(int x)
{
	maillon* c = tete;
	while(c)
	{
		if((*c).info == x)return true;
		c = (*c).suiv;
	}
	return false;
}

//10
bool liste::chercher2(int x)
{
        maillon* c = tete;
        while(c && (*c).info<x )
        {
                c = (*c).suiv;
        }
        return (*c).info == x;
}

//11
int liste::Nb_occurence(int x)
{
	int cpt=0;
	maillon* c = tete;
	while(c)
	{
		if((*c).info == x)cpt++;
		c=(*c).suiv;
	}
	return cpt;
}

//12
bool liste::supprimer(int x)
{
    maillon* p = tete, * pr = NULL;
    
    while (p) {
        if ((*p).info == x) break;
        pr = p;
        p = (*p).suiv;
    }
    
    if (p == NULL) return false;
    
    if (pr == NULL) {
        maillon* q = tete;
        tete = (*tete).suiv;
        (*q).suiv = NULL;
        delete q;
        return true;
    }

    (*pr).suiv = (*p).suiv;
    (*p).suiv = NULL;
    delete p;

    return true;
}


//13
void liste::supprimer_tout() {
    while (tete != NULL) {
        supprimer((*tete).info);
    }
}

//14
liste::liste(const liste & L)
{
	tete=NULL;
	maillon* t = L.tete;
	while(t)
	{
		ajoute((*t).info);
		t=(*t).suiv;
	}
}

void Liste::outils_pour_Recherche (int x, Maillon * & courant, Maillon * & precedent, Maillon * & avant_precedent)
{
      courant = tete; precedent=NULL; avant_precedent=NULL;
      while (courant and (*courant).info !=x)
      {
         avant_precedent=precedent;
         precedent=courant;
         courant= (*courant).suivant;
      }
     // à la sortie de la boucle, si courant = NULL alors x est absent; si precedent=NULL alors x est dans le premier Maillon,
     // si avant_precedent=NULL alors x est dans le Maillon juste après le Maillon de  tête. Sinon x est au milieu et on peut échanger
     // le courant avec le precedent. 
}
















