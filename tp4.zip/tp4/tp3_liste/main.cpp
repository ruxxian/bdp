#include <iostream>
#include "Liste_maillon.hpp"

int main()
{
	//1
	liste L;
	cout << "liste crée avec constructeur par défaut: ";L.afficher();

	//2
	maillon A(5);
	cout << "maillon: ";A.afficher();

	//3
	L.ajoute(4);
	L.ajoute(6);
	L.ajoute(8);
	L.ajoute(8);

	//4
	cout << "fonction afficher: ";
	L.afficher();

	//6
	cout << "fonction afficher recursive: ";
	L.afficher_rec();

	//7
	cout << "fonction afficher recursive inverse: ";
	L.afficher_rec_inverse();

	//8
	cout << "le cardinale de L: " <<L.cardinale(); cout << endl;

	//9
	cout << "6 dans la liste ? (true:1 false:0) reponse: " <<L.chercher(6); cout << endl;

	//10
	cout << "8 dans la liste, avec chercher2 ? (true:1 false:0) reponse: " << L.chercher2(8); cout << endl;

	//11
	cout << "nombre d'occurence de 8: " <<L.Nb_occurence(8); cout << endl;

	//12
	L.supprimer(4);
	L.supprimer(6);
	cout << "suppression de 6 et de 4: ";L.afficher();

	//13
	L.supprimer_tout();
	cout<<"suppression de tout: ";L.afficher();

	//14
	int tab[5] = { 3, 5, 7, 9, 0 };
	liste T(tab,5);
	cout << "liste contructeur avec un tableau: ";T.afficher();

	liste R(T);
	cout << "liste constructeur par recopie: ";R.afficher();

	return 0;
}
