#include "Liste_maillon.hpp"
#include "Liste_rapide.hpp"
#include <iostream>

using namespace std;

int main() {
    // Créer une instance de Liste_Rapide avec une taille maximale de 3 pour la liste principale
    Liste_Rapide liste(3);

    // Ajouter des éléments à la liste
    std::cout << "Ajout de 10, 20, 30, 40, 50..." << std::endl;
    liste.ajouter(10);
    liste.ajouter(20);
    liste.ajouter(30);
    liste.ajouter(40);
    liste.ajouter(50);

    // Afficher l'état des listes principale et secondaire
    liste.princ.afficher();
    liste.second.afficher();
    std::cout << std::endl;

    // Rechercher des éléments
    std::cout << "Recherche de 20: " << (liste.chercher(20) ? "Trouvé" : "Non trouvé") << std::endl;
    std::cout << "Recherche de 40: " << (liste.chercher(40) ? "Trouvé" : "Non trouvé") << std::endl;
    std::cout << "Recherche de 60: " << (liste.chercher(60) ? "Trouvé" : "Non trouvé") << std::endl;

    // Afficher l'état des listes après recherche
    liste.princ.afficher();
    liste.second.afficher();
    std::cout << std::endl;

    // Supprimer des éléments
    std::cout << "Suppression de 30: " << (liste.supprimer(30) ? "Succès" : "Échec") << std::endl;
    std::cout << "Suppression de 50: " << (liste.supprimer(50) ? "Succès" : "Échec") << std::endl;
    std::cout << "Suppression de 60: " << (liste.supprimer(60) ? "Succès" : "Échec") << std::endl;

    // Afficher l'état des listes après suppression
    liste.princ.afficher();
    liste.second.afficher();
    std::cout << std::endl;

    // Ajouter de nouveaux éléments
    std::cout << "Ajout de 60, 70, 80..." << std::endl;
    liste.ajouter(60);
    liste.ajouter(70);
    liste.ajouter(80);

    // Afficher l'état des listes après ajout
    liste.princ.afficher();
    liste.second.afficher();
    std::cout << std::endl;

    return 0;
}