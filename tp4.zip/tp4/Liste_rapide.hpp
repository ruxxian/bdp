#include "Liste_maillon.hpp"
  
#ifndef _lister_
#define _lister_
class lister
{
	
private: 
friend class liste;
friend class maillon;
int size_p;
int nbe;
liste *princ;
liste *second;

public:
lister(int size);
~lister();

bool chercher(int n);
bool ajoute(int n);
bool supprimer(int n);
void outils_pour_Recherche (int x, Maillon * & courant, Maillon * & precedent, Maillon * & avant_precedent);
};
#endif

