#include "Liste_rapide.hpp"

lister::lister(int size)
{
size_p=size;
nbe=0;
princ = new liste();
second = new liste();
}   

lister::~lister()
{
	delete princ;
	delete second;
}

bool Liste_Rapide::ajouter(int x) {
    // Si l'élément n'existe pas, la fonction chercher l'ajoutera automatiquement
    if (!chercher(x)) {
        return true; // L'élément a été ajouté
    }
    return false; // L'élément existait déjà
}

bool Liste_Rapide::supprimer(int x) {
    // Variables pour stocker les résultats de la recherche
    maillon* courant = NULL;
    maillon* precedent = NULL;
    maillon* avant_precedent = NULL;

    // Rechercher l'élément dans la liste principale
    princ->outils_pour_Recherche(x, courant, precedent, avant_precedent);

    if (courant != NULL) {
        // Si l'élément est trouvé dans la liste principale
        if (precedent == NULL) {
            // Cas où l'élément est en tête de la liste principale
            princ->tete = courant->suiv;
        } else {
            // Cas où l'élément est au milieu ou à la fin de la liste principale
            precedent->suiv = courant->suiv;
        }
        delete courant; // Libérer la mémoire
        nbe--; // Décrémenter le nombre d'éléments dans la liste principale
        return true; // L'élément a été supprimé
    }

    // Si l'élément n'est pas trouvé dans la liste principale, rechercher dans la liste secondaire
    second->outils_pour_Recherche(x, courant, precedent, avant_precedent);

    if (courant != NULL) {
        // Si l'élément est trouvé dans la liste secondaire
        if (precedent == NULL) {
            // Cas où l'élément est en tête de la liste secondaire
            second->tete = courant->suiv;
        } else {
            // Cas où l'élément est au milieu ou à la fin de la liste secondaire
            precedent->suiv = courant->suiv;
        }
        delete courant; // Libérer la mémoire
        return true; // L'élément a été supprimé
    }

    // Si l'élément n'a pas été trouvé dans les deux listes
    return false;
}

bool lister::chercher(int n) {
    maillon *c = nullptr, *pr = nullptr, *apr = nullptr;
    princ->outils_pour_Recherche(n, c, pr, apr);

    if (c) {
        // L'élément est trouvé dans la liste principale
        if (pr == nullptr) {
            // L'élément est déjà en tête de la liste principale
            return true;
        }
        // Déplacer l'élément vers l'avant dans la liste principale
        if (apr) {
            apr->suiv = c;
        }
        pr->suiv = c->suiv;
        c->suiv = princ->tete;
        princ->tete = c;
        return true;
    } else {
        // Rechercher dans la liste secondaire
        maillon *cs = nullptr, *prs = nullptr, *aprs = nullptr;
        second->outils_pour_Recherche(n, cs, prs, aprs);

        if (cs) {
            // L'élément est trouvé dans la liste secondaire
            if (nbe < size_p) {
                // Il y a de la place dans la liste principale
                if (prs) {
                    prs->suiv = cs->suiv; // Retirer cs de la liste secondaire
                } else {
                    second->tete = cs->suiv; // cs était en tête de la liste secondaire
                }
                pr->suiv = cs; // Ajouter cs à la tête de la liste principale
                cs->suiv = NULL;
                nbe++;
                return true;
            } else if (nbe > size_p) {
		    // Le dernier élément de la liste principale est déjà connu grâce à precedent
		    maillon* dernier = precedent;

		    // Détacher le dernier élément de la liste principale
		    if (dernier) {
		        if (avant_precedent) {
		            avant_precedent->suiv = nullptr; // Détacher le dernier élément
		        } else {
		            princ->tete = nullptr; // Cas où la liste principale n'a qu'un seul élément
		        }

		        // Ajouter le dernier élément à la tête de la liste secondaire
		        dernier->suiv = second->tete;
		        second->tete = dernier;
		        nbe--;
		    }
		}
        }
    }

    // Si l'élément n'est pas trouvé, l'ajouter à la liste principale
    maillon* nouveau = new maillon(n);
    nouveau->suiv = princ->tete;
    princ->tete = nouveau;
    nbe++;

    // Si la liste principale dépasse sa capacité, déplacer le dernier élément vers la liste secondaire
    if (nbe > size_p) {
        
        if (apr) {
            apr->suiv = nullptr; // Détacher le dernier élément de la liste principale
        }
        pr->suiv = second->tete; // Ajouter le dernier élément à la tête de la liste secondaire
        second->tete = pr;
        nbe--;
    }
    //on ajoute les élément de la seconde liste dans la première list6e tant qu'il reste de la place
    while(nbe<size_p)
	{
		(*pr).suiv = (*second).tete;
		pr = (*pr).suiv;
		(*pr).suiv = NULL;
		(*second).tete = *((*second).tete).suiv;
		nbe++;
	}

    return false;
}