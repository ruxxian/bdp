#include <iostream>
#include "Point.hpp"
#include "Col_points.hpp"
using namespace std;

int main(int argc, char const *argv[])
{
	Point A;
	A.afficher();

	Point B;
	B.saisir();
	B.afficher();

	Point C(0,0);
	cout<<C.distance(B)<<endl;

	int N ;
	Point *T=saisir_points(N) ;
	afficher(T,N) ;
	delete[] T;

	Col_points Col;
	col.ajouter((0,0))
	col.ajouter((0,1))
	col.ajouter((0,2)) 
	col.afficher();

	return 0;
};