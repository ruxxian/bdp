#include <iostream>
#include "Col_points.hpp"
using namespace std;

//Point* Col_points::getT() const {return T;}
//int Col_points::getnbp() const {return nbp;}
//int Col_points::getcap() const {return cap;}

//constructeur-destructeur
Col_points::Col_points()
{
	cap=100;
	size=0;
	T=new Point[cap];
}

Col_points::Col_points(Point * Tab, int n)
{
	if(n>100)cap=n;
	else cap=100;
	T = new Point[cap];
	nbp=n;

	for (int i = 0; i < n; ++i)
	{
		T[i]=Tab[i];
	}
}

Col_points::Col_points(const Col_points & collection)
{
	Col_points(collection.T, collection.nbp)
}

Col_points::~Col_points()
{
	delete[] T;
}

//fonction de la class
void Col_points::afficher()
{
	for (int i = 0; i < nbp; ++i)
	{
		T[i].afficher();
	}
}

bool Col_points::present(const Point & P) const
{
	for (int i = 0; i < nbp; ++i)
	{
		if(T[i].identique(P))return true;
	}
	return false;
}

bool Col_points::supprimer(Point & P)
{
	if(present(P))return true;
	if(nbp<cap)
	{
		for (int i = 0; i < nbp; ++i)
		{
			if(T[i].identique(P))
			{
				for (int j = i ; j < nbp; ++j)
				{
					T[i]=T[i+1];
				}
				nbp--;
				return true;
			}
		}
		return false;
	}
	return false;
}

bool Col_points::ajouter(Point & P)
{
	if(nbp<cap && !present(P))
	{
		T[nbp++]=P;
		return true;
	}
	return false;
}

bool Col_points::ajouter_bis(Point & P)
{
	if(!ajouter(P))
	{
		Point* temp = new Point[nbp];
		for (int i = 0; i < nbp; ++i)
		{
			temp[i]=T[i];
		}

		int nbpb=nbp;
		nbp*=2;
		cap=nbp;
		delete[] T;
		T = new Point[nbp];
		for (int i = 0; i < nbpb; ++i)
		{
			T[i]=temp[i];
		}

		delete[] temp;
		return ajouter(P);
	}
	return true;
}

void Col_points::ajouter_tab_point(Point * Tab, int n)
{
	for (int i = nbp; i < nbp+n; ++i)
	{
		(*this).ajouter_bis(Tab[i]);
	}
	nbp+=n;
}

void Col_points::intersection(const Col_points & A, Col_points & B )
{
	B.nbp=0;
	B.cap=100;
	for (int i = 0; i < A.nbp; ++i)
	{
		for (int j = 0; j < nbp; ++i)
		{
			if(A.T[i]==T[i])
			{
				if (!(B.present(A.T[i])))
				{
					B.ajouter(A.T[i]);
					break;
				}
			}
		}
	}
}

void Col_points::Union(const Col_points & A, Col_points & B)
{
	B.nbp = 0;
	for (int i = 0; i < nbp; ++i)
	{
    	B.ajouter(T[i]);
    }

    for (int i = 0; i < A.nbp; ++i) {
		if (!B.present(A.T[i])) {
			B.ajouter(A.T[i]);
		}
	}
}

/*
Écrire une fonction qui renvoie 5 résultats : 
le point ayant la plus petite abscisse,
le point ayant la plus grande abscisse,
le point ayant la plus petite ordonnée,
le point ayant la plus grande ordonnée,
le centre de tous les points de la collection.
*/

void Col_points::five_result
(Point & point_min_x,Point & point_max_x,Point & point_max_y,Point & point_min_y,Point & centre)
{
	if (nbp == 0)
	{
	 	cout << "La collection de points est vide.\n";
        return;
    }

    point_min_x = T[0];
	point_max_x = T[0];
	point_min_y = T[0];
	point_max_y = T[0];
	double somme_x = 0, somme_y = 0;

    
        for (int i = 0; i < nbp; ++i) {
            const Point& p = T[i];

            // Trouver le point avec la plus petite abscisse
            if (p.x < point_min_x.x) {
                point_min_x = p;
            }
            // Trouver le point avec la plus grande abscisse
            if (p.x > point_max_x.x) {
                point_max_x = p;
            }
            // Trouver le point avec la plus petite ordonnée
            if (p.y < point_min_y.y) {
                point_min_y = p;
            }
            // Trouver le point avec la plus grande ordonnée
            if (p.y > point_max_y.y) {
                point_max_y = p;
            }
            // Somme des abscisses et des ordonnées pour calculer le centre
            somme_x += p.x;
            somme_y += p.y;
        }

        // Calcul du centre (moyenne des abscisses et ordonnées)
        centre = Point(somme_x / nbp, somme_y / nbp);
}