#include "Point.hpp"
class Col_points
{
private:
	Point * T;
	int cap;
	int nbp;
public:
	Col_points();
	Col_points(Point * T, int n);
	Col_points(const Col_points & collection);

	~Col_points();

	bool ajouter(Point & P);
	void afficher();
	bool present(const Point & P) const;
	bool supprimer(Point & P);
	bool ajouter_bis(Point & P);
	void ajouter_tab_point(Point * Tab, int n);
	void intersection( const Col_points & A, Col_points & B );
	void Union( const Col_points & A, Col_points & B );
	void Col_points::five_result(Point & point_min_x,Point & point_max_x,Point & point_max_y,Point & point_min_y,Point & centre);

	Point* getT() const;
	int getnbp() const;
	int getcap() const;
};