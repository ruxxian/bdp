#include "expression.hpp"
#include <iostream>
#include <string>
using namespace std;

int main()
{
    string test = "3.5 3.8 + 3 *";
    expression calc;
    cout<<calc.evaluer(test)<<endl;
    test = "(3.5 + 3.8)*3";
    cout<<calc.evaluerinfixee(test)<<endl;
    return 0;

}
