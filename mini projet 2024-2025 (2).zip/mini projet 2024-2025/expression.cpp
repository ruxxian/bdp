#include "expression.hpp"
#include "cPile.hpp"
#include "Pile.hpp"
#include <sstream>
#include <string>
using namespace std;

double expression::evaluer(string s1)
{
	istringstream s(s1);
	string h;
    Pile chaine;
	while(s >> h)
	{ 
		if(h!= "+" and h != "-" and h != "*" and h!="/") 
		{
			double d = stod(h);
			//empiler l'opérande
            chaine.empiler(d);
		}else if(chaine.nbe>=2){
			//depiler les deux dernier et appliquer l'opérateur
			double a = chaine.depiler();
			double b = chaine.depiler();
			
			if(h == "+")
			{
				chaine.empiler(a+b);
			}
			else if(h == "-")
			{
				chaine.empiler(a-b);
			}
			else if(h == "*")
			{
				chaine.empiler(a*b);
			}
			else if(h == "/")
			{
				chaine.empiler(a/b);
			}
		}
	}
	return(chaine.depiler());
}


int priorite(char op) {
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/') return 2;
    if (op == '^') return 3;
    return 0;
}

bool associatifGauche(char op) {
    return op != '^';
}

string expression::suffixee(string exp) {
    cPile pile;
    string sortie;
    istringstream iss(exp);
    char c;
    
    while (iss >> c) { 
        
        if (isdigit(c)) {
     
            sortie += string(1,c) + ' ';
        }
        else if (c == '(') {
            pile.empiler(c);
        }
        else if (c == ')') {
            while (!pile.vide() && pile.sommet() != '(') {
                sortie += string(1, pile.depiler()) + ' ';
            }
            pile.depiler(); // Dépiler '('
        }
        else { // Opérateur
            while ((associatifGauche(c)&& !pile.vide() && priorite(c) <= priorite(pile.sommet()))||
            (!associatifGauche(c) && !pile.vide() && priorite(c) < priorite(pile.sommet())))
            {
                sortie += string(1, pile.depiler()) + ' ';
            }
            pile.empiler(c);
        }
    }
    
    // Vider la pile
    while (!pile.vide()) {
        sortie += string(1, pile.depiler()) + ' ';
    }
    
    // Supprimer l'espace final si existant
    if (!sortie.empty() && sortie.back() == ' ') {
        sortie.pop_back();
    }
    
    return sortie;
}

double expression::evaluerinfixee(string exp){
	exp = suffixee(exp);
	return evaluer(exp);
}