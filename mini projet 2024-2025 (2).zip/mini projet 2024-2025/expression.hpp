#include <string>
using namespace std;

class expression
{
public:
    double evaluer(string s1);
    string suffixee(string exp);
    double evaluerinfixee(string exp);
};
