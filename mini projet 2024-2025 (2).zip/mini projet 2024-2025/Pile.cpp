#include "Pile.hpp"
#include <string> 
#include <iostream>

using namespace std;


maillon::maillon(double x)
{
    info = x;
    suivant = nullptr;
}

maillon::~maillon()
{
  
}

Pile::Pile()
{
    tete = nullptr;
    nbe = 0;
}

Pile::~Pile()
{
    if(tete) delete tete;
}

void Pile::empiler(double x)
{
	maillon * p = new maillon(x);
	p->suivant = tete;
	tete = p;
	nbe++;
}

double Pile::depiler() {
    if (vide()) {
        // Stack is empty, throw an exception
        throw std::out_of_range("Cannot depile from empty stack.");
    } else {
        maillon *temp = tete;
        double retour = temp->info;
        tete = tete->suivant;
        delete temp;
      	nbe--;
        return retour;
    }
}

bool Pile::vide()
{
    return(!(tete));
}

