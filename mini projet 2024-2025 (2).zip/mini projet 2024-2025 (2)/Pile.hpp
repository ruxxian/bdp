#include <string>
using namespace std;

class maillon
{
private:
    double info;
    string c;
    maillon* suivant;
    friend class Pile;
    friend class expression;
public:
    maillon(double x);
    maillon(string x);
    ~maillon();
};

class Pile
{
private:
    maillon * tete;
    int nbe;
    friend class expression;
public:
    Pile();
    ~Pile();
    void empiler(double x);
    void empiler(string x);
    double dbdepiler();
    string stdepiler();
    bool vide();
    string stsommet();
    double dbsommet();
};



