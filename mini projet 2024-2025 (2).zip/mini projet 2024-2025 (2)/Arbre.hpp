#include <string>
using namespace std;

class noeud {
    string type;     // 'o' pour opérateur, 'f' pour feuille (valeur)
    string ope;      // opérateur : +, -, *, /
    double val;    // valeur si c’est une feuille
    noeud* fg;     // fils gauche
    noeud* fd;     // fils droit
    friend class Arbre;
public:

    //constructeur sans arguments
    noeud(){
    	type = "f";     
	    ope = "";     
	    val = 0;    
	    fg = fd = nullptr;
    }

    // Constructeur pour une feuille (valeur)
    noeud(double valeur) {
        type = "f";
        val = valeur;
        fg = fd = nullptr;
    }

    noeud(string operateur, noeud* gauche, noeud* droit) {
        type = "o";
        ope = operateur;
        fg = gauche;
        fd = droit;
    }

    // Destructeur récursif pour libérer les sous-arbres
    ~noeud() {
        delete fg;
        delete fd;
    }
};


class Arbre
{
	noeud* racine;
public:
	//constructeur sans arguments
	Arbre(){racine = nullptr;}

	Arbre(string infixe);
	
	// Destructeur
	~Arbre(){delete racine;}

    //fonction évvaluer un arbre
	double evaluer(){
        return rec_evaluer(racine);
    }
    double rec_evaluer(noeud*& n);

    void afficher();
    string afficher_rec(noeud*& n);
};