 

03/04/2025 8h30:
exercice 1 fait

    fonction:
    empiler 
    depiler
    vide
    et tout les constructeur et destructeur
    j'ai crée une class expression pour utiliser la fonction evaluer sur la class pile

10/01/2025 11h30:
exercice 2:

j'ai réussis à finir
j'ai combiner mes deux classes pile en une seule
compiler: g++ main.cpp Pile.cpp expression.cpp -o test