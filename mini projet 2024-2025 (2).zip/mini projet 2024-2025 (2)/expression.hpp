#include <string>
using namespace std;

class expression
{
    friend class Arbre;
public:
    double evaluer(string s1);
    string suffixee(string exp);
    double evaluerinfixee(string exp);
};
