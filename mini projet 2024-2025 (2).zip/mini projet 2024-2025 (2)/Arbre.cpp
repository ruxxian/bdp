#include <string>
#include <stack>
#include <sstream> 
#include <iostream>
#include "Arbre.hpp"
#include "expression.hpp"
using namespace std;

//convertir infixe vers suffixe
Arbre::Arbre(string infixe){

	expression calc;
	string sufixee = calc.suffixee(infixe);

	std::stack<noeud*> pile;
	istringstream f(sufixee);
	string h;

	while( f >> h){
		if( h!= "+" && h != "-" && h != "*" && h!="/" && h!="^"){
			//empiler l'opérande
            double d = stod(h);
            pile.push(new noeud(d));
		}else{
			noeud* droit = pile.top(); pile.pop();
            noeud* gauche = pile.top(); pile.pop();
            pile.push(new noeud(h, gauche, droit));
		}
	}

	racine = pile.top();
}


//evaluer un arbre
double Arbre::rec_evaluer(noeud*& n) {
    if (!n) return 0; // sécurité

    if (n->type == "f") {
        return n->val; // feuille : retourne la valeur
    } else if (n->type == "o") {
        double g = rec_evaluer(n->fg); // évaluer fils gauche
        double d = rec_evaluer(n->fd); // évaluer fils droit

        if(n->ope == "+" ) {
            return g + d;
        }
        else if(n->ope == "-" ) {
            return g - d;
        }
        else if(n->ope == "*" ) {
            return g * d;
        }
        else if(n->ope == "/" ) {
            return g / d;
        }
        else if(n->ope == "^") {
            int p = 1;
            for(int i=0; i<d; i++){
                p*=g;
            }
            return p;
        }
    }
    return 0;
}


//afficher un arbre
void Arbre::afficher(){
    cout << afficher_rec(racine);
}
string Arbre::afficher_rec(noeud*& n){
    if (!n) return 0; // sécurité

    if(n->type == "f"){
        ostringstream oss;
        oss << n->val;
        return oss.str();
    }
    else if (n->type == "o")
    {
        string g = afficher_rec(n->fg);
        string d = afficher_rec(n->fd);

        return "("+ g + n->ope + d + ")";
    }

    return "\0";
}



string Arbre::afficher_rec(noeud*& n){
    if (!n) return 0; // sécurité

    if(n->type == "f"){
        ostringstream oss;
        oss << n->val;
        return oss.str();
    }
    else if (n->type == "o")
    {
        string g = afficher_rec(n->fg);
        string d = afficher_rec(n->fd);

        
    }

    return "\0";
}