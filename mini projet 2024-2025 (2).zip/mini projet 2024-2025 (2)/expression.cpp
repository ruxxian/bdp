#include "expression.hpp"
#include "Pile.hpp"
#include <sstream>
#include <iostream>
#include <string>
using namespace std;

double expression::evaluer(string s1)
{
	istringstream s(s1);
	string h;
    Pile piledouble;
	while(s >> h)
	{
		if( h!= "+" && h != "-" && h != "*" && h!="/" && h!="(" && h!=")" && h!="^"){
			//empiler l'opérande
            double d = stod(h);
            piledouble.empiler(d);
		}
		else if(piledouble.nbe>=2){
			//depiler les deux dernier et appliquer l'opérateur
			double a = piledouble.dbdepiler();
			double b = piledouble.dbdepiler();
			
			if(h == "+")
			{
				piledouble.empiler(a+b);
			}
			else if(h == "-")
			{
				piledouble.empiler(b-a);
			}
			else if(h == "*")
			{
				piledouble.empiler(a*b);
			}
			else if(h == "/")
			{
				piledouble.empiler(b/a);
			}
            else if(h == "^")
            {
                double t = b;
                for(int i=1; i<a; i++)
                {
                    b = b * t;
                }
                piledouble.empiler(b);
            }
		}
	}
	return(piledouble.dbdepiler());
}


int priorite(string op) {
    if (op == "+" || op == "-") return 1;
    if (op == "/" || op == "*") return 2;
    if (op == "^") return 3;
    return 0;
}

bool associatifGauche(string op) {
    return op != "^";
}

string expression::suffixee(string exp) {

    int i=0;
    string s;
    while (i<exp.size()) //mettre des espaces autour des opérateurs
	{	
		if(exp[i]==')' or exp[i]=='(' or exp[i]=='*' or exp[i]=='+' or exp[i]=='-' or exp[i]=='/' or exp[i]=='^' )
		{
			s+=' ';
			s+=exp[i];
			s+=' ';
		}
		else s+=exp[i];
		i++;
	}

    cout<<s<<endl; //vérification

    Pile pile; //pile des opérateur char
    string sortie; //valeur à retourner
    istringstream f(s); // creation du flux
    string obj;
    
    while ( f >> obj) {
        if (obj != "+" && obj != "-" && obj != "*" && obj != "/" && obj != "(" && obj != ")" && obj != "^") {
            sortie += obj + " "; // l'élément est un nombre
        }
        else if (obj == "(") {
            pile.empiler(obj);
        }
        else if (obj == ")") {
            while (!pile.vide() && pile.stsommet() != "(") {;
                sortie += pile.stdepiler() + " ";
            }
            if (pile.vide())
            {
                cerr << "parentèses" << endl;
            }
            else{ 
                pile.stdepiler();
            }
        }
        else { // opérateur
            while (!pile.vide() && pile.stsommet() != "(" &&
                  ((associatifGauche(obj) && priorite(obj) <= priorite(pile.stsommet())) ||
                   (!associatifGauche(obj) && priorite(obj) < priorite(pile.stsommet())))) {
                sortie += pile.stdepiler();
                sortie += " ";
            }
            pile.empiler(obj);
        }
    }

    while (!pile.vide()) {
        if (pile.stsommet() == "(") cerr << "parentèses" << endl;
        sortie += pile.stdepiler();
        sortie += " ";
    }

    return sortie;
}


double expression::evaluerinfixee(string exp){
	exp = suffixee(exp);
	return evaluer(exp);
}