#include "Liste_rapide.hpp"

lister::lister(int size)
{
size_p=size;
nbe=0;
princ = new liste();
second = new liste();
compare=0;
affectation=0;
}   

lister::~lister()
{ 
	delete princ;
	delete second;
}

bool lister::supprimer(int x)
{
    // Variables pour stocker les résultats de la recherche
    maillon* courant = nullptr;
    maillon* precedent = nullptr;
    maillon* avant_precedent = nullptr;

    // Rechercher l'élément dans la liste principale
    (*princ).outils_pour_Recherche(x, courant, precedent, avant_precedent);

    princ->compare++;
    if (courant != nullptr)
    {
        // Si l'élément est trouvé dans la liste principale
        princ->compare++;
        if (precedent == nullptr) {
            // Cas où l'élément est en tête de la liste principale
            princ->tete = courant->suiv;
        } else {
            // Cas où l'élément est au milieu ou à la fin de la liste principale
            precedent->suiv = courant->suiv;
        }
        princ->affectation++;
        delete courant; // Libérer la mémoire
        nbe--; // Décrémenter le nombre d'éléments dans la liste principale
        compare = princ->compare + second->compare;
        affectation = princ->affectation + second->affectation;
        return true; // L'élément a été supprimé
    }
    else
    {
        // Si l'élément n'est pas trouvé dans la liste principale, rechercher dans la liste secondaire
        (*second).outils_pour_Recherche(x, courant, precedent, avant_precedent);
        second->compare++;
        if (courant != nullptr) {
            // Si l'élément est trouvé dans la liste secondaire
            second->compare++;
            if (precedent == nullptr) {
                // Cas où l'élément est en tête de la liste secondaire
                second->tete = courant->suiv;
            } else {
                // Cas où l'élément est au milieu ou à la fin de la liste secondaire
                precedent->suiv = courant->suiv;
            }
            second->affectation++;
            delete courant; // Libérer la mémoire
            compare = princ->compare + second->compare;
            affectation = princ->affectation + second->affectation;
            return true; // L'élément a été supprimé
        }
    }
    // Si l'élément n'a pas été trouvé dans les deux listes
    return false;
}

void lister::chercher(int n) {
    maillon *c = nullptr, *pr = nullptr, *apr = nullptr;
    (*princ).outils_pour_Recherche(n, c, pr, apr);
    bool trouver = false;

    if (c) {
        trouver = true;
        // L'élément est trouvé dans la liste principale
        if (pr != nullptr) {
            // Déplacer l'élément vers l'avant dans la liste principale
            if (apr) {
                apr->suiv = c;
            }
            pr->suiv = c->suiv;
            c->suiv = princ->tete;
            princ->tete = c;
            trouver = true;
        }
    } else {
        // Rechercher dans la liste secondaire
        maillon *cs = nullptr, *prs = nullptr, *aprs = nullptr;
        (*second).outils_pour_Recherche(n, cs, prs, aprs);

        if (cs) 
        {
            trouver = true;
            // L'élément est trouvé dans la liste secondaire
            if (nbe < size_p)
            {
                // Il y a de la place dans la liste principale
                if (prs) {
                    prs->suiv = cs->suiv; // Retirer cs de la liste secondaire
                } else {
                    second->tete = cs->suiv; // cs était en tête de la liste secondaire
                }
                pr->suiv = cs; // Ajouter cs à la tête de la liste principale
                cs->suiv = nullptr;
                nbe++;
                trouver = true;
            }
            else if (nbe >= size_p)
            {
                // Le dernier élément de la liste principale est déjà connu grâce à precedent
    		    maillon* dernier = pr;

    		    // Détacher le dernier élément de la liste principale
    		    if (dernier) {
    		        if (apr) {
    		            apr->suiv = cs; // Détacher le dernier élément
                        if (prs)
                        {
                            prs->suiv = cs->suiv; // Retirer cs de la liste secondaire
                        } 
                        else
                        {
                            second->tete = cs->suiv; // cs était en tête de la liste secondaire
                        }
    		        } else {
    		            princ->tete = cs;
    		        }
                    cs->suiv = nullptr;
    		        // Ajouter le dernier élément à la tête de la liste secondaire
    		        dernier->suiv = second->tete;
    		        second->tete = dernier;
    		        nbe--;
    		    }
                else
                {
                    princ->tete = cs;
                    second->tete = cs->suiv;
                    cs->suiv = nullptr;
                }
            }
        }
    }

    // Si la liste principale dépasse sa capacité, déplacer le dernier élément vers la liste secondaire
    if (nbe > size_p) {
        
        pr = nullptr; avpr = nullptr; c = princ->tete;
        while(c != nullptr)
        {
            avpr = pr;
            pr = c;
            c = c->suiv;
        }
        avpr->suiv = nullptr;
        pr->suiv = second->tete; // Ajouter le dernier élément à la tête de la liste secondaire
        second->tete = pr;
        nbe--;
    }
    //on ajoute les élément de la seconde liste dans la première liste tant qu'il reste de la place
    while(nbe<size_p)
	{    
        if(pr)
        {
            (*pr).suiv = (*second).tete;
    		pr = (*pr).suiv;
    		(*pr).suiv = nullptr;
    		(*second).tete = (*(*second).tete).suiv;
    		nbe++;
        }
	}

    return trouver;
}

void lister::afficher()
{   cout << "première liste: ";
    (*princ).afficher();
    cout << endl << "second liste: ";
    (*second).afficher();
    cout << endl;
}

bool lister::ajouter(int x)
{
    if(chercher(x))return false;
    maillon* nouveau = new maillon(n);
    nouveau->suiv = princ->tete;
    princ->tete = nouveau;
    nbe++;
    return true;
}