#include "Liste_rapide.hpp"
#include <iostream>

using namespace std;

int main()
{
    lister L();
    int x;
    char c;
    while(cin>>c and cin>>x)
    {
        if (c == 'r')
        {
            L.chercher(x);
        }
        else if (c == 's')
        {
            L.supprimer(x);
        }
        else if (c == 'i')
        {
            L.ajoute(x);
        }
        else if (c == '')
        {
            /* code */
        }
    }
    return 0;
}