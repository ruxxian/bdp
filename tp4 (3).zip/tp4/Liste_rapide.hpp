#include "Liste.hpp"
  
#ifndef _lister_
#define _lister_

class lister
{
int size_p;
int nbe; 
liste *princ;
liste *second;
int compare;
int affectation;

public:
lister(int size);
~lister();

void afficher();
bool chercher(int n);
bool ajouter(int n);
bool supprimer(int n);
};
#endif

