#include <iostream>
#include "Point.hpp"
using namespace std;

int main(int argc, char const *argv[])
{
	Point A;
	A.afficher();

	Point B;
	B.saisir();
	B.afficher();

	Point C(0,0);
	cout<<C.distance(B)<<endl;

	int N ;
	Point *T=saisir_points(N) ;
	afficher(T,N) ;
	delete[] T;
	return 0;
};