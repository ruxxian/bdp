#include "Point.hpp"
class Col_points
{
private:
	Point * T;
	int cap;
	int nbp;
public:
	Col_points();
	Col_points(Point * T, int n);
	Col_points(const Col_points & collection);

	~Col_points();

	bool ajouter(Point & P);
	bool present(const Point & P) const;
	bool supprimer(Point & P);
	bool ajouter_bis(Point & P);
	void ajouter_tab_point(Point * Tab, int n);
	void intersection( const Col_points & A, Col_points & B );

	Point* getT() const;
	int getnbp() const;
	int getcap() const;
};