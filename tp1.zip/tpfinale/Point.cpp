#include <iostream>
#include <math.h>
#include "Point.hpp"
using namespace std;

void Point::afficher() const
{
cout<<"("<<x<<";"<<y<<") ";
}

void Point::saisir()
{
	cout<<"entrer x puis y:";
	cin>>x>>y;
}

double Point::distance(const Point & P) const
{
	return(sqrt((x-P.x)*(x-P.x)+(y-P.y)*(y-P.y)));
}

Point::Point(double a, double b)
{
x=a;y=b;
}

Point::Point()
{
	x=0;y=0;
}

bool Point::identique(const Point & P) const
{
	return (*this).distance(P)<0.0001;
}

//fonction en dehors de la class

void afficher(Point * T, int size)
{
	for (int i = 0; i < size; ++i)
	{
		T[i].afficher();
	}
}

void saisir(Point * T, int size)
{
	for (int i = 0; i < size; ++i)
	{
		cout<<"point "<<i+1<<" sur "<<size<<endl;
		T[i].saisir();
	}
}

Point *saisir_points(int &n)
{
	cout<<"taille du tableau: ";
	cin>>n;
	Point * T = new Point[n];
	saisir(T,n);
	return T;
}





