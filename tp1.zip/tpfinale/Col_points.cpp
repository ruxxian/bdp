#include <iostream>
#include "Col_points.hpp"
using namespace std;

Point* Col_points::getT() const {return T;}
int Col_points::getnbp() const {return nbp;}
int Col_points::getcap() const {return cap;}

Col_points::Col_points()
{
	cap=100;
	size=0;
	T=new Point[cap];
}

Col_points::Col_points(Point * Tab, int n)
{
	T = new Point[n];
	nbp=n;
	if(n>100)cap=n;

	for (int i = 0; i < n; ++i)
	{
		T[i]=Tab[i];
	}
}

Col_points::~Col_points()
{
	delete[] T;
}

bool Col_points::present(const Point & P) const
{
	for (int i = 0; i < nbp; ++i)
	{
		if(T[i].identique(P))return true;
	}
	return false;
}

bool Col_points::supprimer(Point & P)
{
	if(present(P))return true;
	if(nbp<cap)
	{
		for (int i = 0; i < nbp; ++i)
		{
			if(T[i].identique(P))
			{
				for (int j = i ; j < nbp; ++j)
				{
					T[i]=T[i+1];
				}
				nbp--;
				return true;
			}
		}
		return false;
	}
	return false;
}

bool Col_points::ajouter(Point & P)
{
	if(nbp<cap && !present(P))
	{
		T[nbp++]=P;
		return true;
	}
	return false;
}

bool Col_points::ajouter_bis(Point & P)
{
	if(!ajouter(P))
	{
		Point* temp = new Point[nbp];
		for (int i = 0; i < nbp; ++i)
		{
			temp[i]=T[i];
		}

		int nbpb=nbp;
		nbp*=2;
		cap=nbp;
		delete[] T;
		T = new Point[nbp];
		for (int i = 0; i < nbpb; ++i)
		{
			T[i]=temp[i];
		}

		delete[] temp;
		return ajouter(P);
	}
	return true;
}

void Col_points::ajouter_tab_point(Point * Tab, int n)
{
	for (int i = nbp; i < nbp+n; ++i)
	{
		(*this).ajouter_bis(Tab[i]);
	}
	nbp+=n;
}

Col_points::Col_points(const Col_points & collection)
{
	int collec_nbp = collection.getnbp();
	nbp=collec_nbp;
	if(collec_nbp>100)cap=collec_nbp;
	else cap=100;

	T = new Point[cap];
	ajouter_tab_point(collection.getT(), collec_nbp);
}

Col_points::Col_points(const Col_points & col1, Col_points & col2 )
{
	cap=100;

	int size_col1 = col1.getnbp();
	Point* T1 = col1.getT();

	int size_col2 = col2.getnbp();
	Point* T2 = col2.getT();

	int nbp = size_col1 + size_col1;
	if (nbp > 100)cap=nbp;
	
	T = new Point[cap];

	ajouter_tab_point(T1,size_col1);
	ajouter_tab_point(T2,size_col2);

}
