class Point
{
private:
	double x;
	double y;
public:
	void afficher() const;
	void saisir();

	double distance(const Point & P) const;
	bool identique(const Point & P) const;

	Point(double a, double b);
	Point();
};

void afficher(Point * T, int size);
void saisir(Point * T, int size);
Point *saisir_points(int &n);