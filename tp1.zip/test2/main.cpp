#include <iostream>
#include "Point.hpp"
using namespace std;

int main()
{
	Point A;
	A.afficher();
	cout<<endl;
	
	Point B;
	B.saisir();
	B.afficher();
	cout<<endl;
	
	int N ;
	Point *T = saisir_points(N) ;
	afficher(T,N);
	delete[] T;
	
	return(0);
}
