#include <Point.hpp>

class Col_point
{
private:
	Point *T;
	int size;
	int cap;
public:
	Col_points();
	~Col_points();
	
	bool present( const Point & P)const;
	bool ajouter(const Point & P)const;
}
