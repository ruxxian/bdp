#include <iostream>
#include <math.h>
#include "Point.hpp"
using namespace std;

Point::Point(double a, double b)
{
x=a;y=b;
}

Point::Point()
{
x=0;y=0;
}

void Point::afficher()
{
cout<<"("<<x<<";"<<y<<") ";
}

double Point::distance(Point & P)
{
	return(sqrt((P.x-x)*(P.x-x)-(P.y-y)*(P.y-y)));
}

void afficher(Point *T, int size)
{
	for(int i=0; i<size; ++i)
	{
		T[i].Afficher();
	}
	cout<<endl;
}

void Point::saisir()
{
	cout<<"saisir x et y:";
	cin>>x>>y;
}

void saisir(Point *T, int size)
{
	for(int i=0; i<size; i++)
	{
		T[i].saisir();
	}
}

void *saisir_points(int & n)
{
	Point *tab = new Point[n];
	saisir(tab,n);
	return tab;
}

bool identique(Point & P)
{
	return( (*this).distance(P)<0.0001 );
}












