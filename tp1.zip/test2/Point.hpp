
class Point
{
private:
	double x,y;
public:
	Point();
	Point(double a, double b);
	
	void Afficher();
	void saisir();
	double distance(Point & P);
	bool identique(Point & P);
	
};

void Afficher_tab();
void saisir(Point *T, int size);
void *saisir_points(int & n);
