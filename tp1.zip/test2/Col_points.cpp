#include "Col_points.hpp"
#include <iostream>

Col_points::Col_points()
{
	cap=100;
	size=0;
	T = new Point[cap];
}

Col_points::~Col_points()
{
	delete[] T;
}

bool Col_points::present(const Point & P)
{
	for(int i=0; i<size; i++)
	{
		if(T[i].identique(P))
		{
		return true;
		}
	}
	return false;
}

bool Col_points::ajouter(Point & P)
{
	if(!(*this).present(P) && size<cap)
	{
	T[size]=P;
	size++;
	return true;
	}
	return false;
}

bool Col_points::supprimer(Point & P)
{
	if(present(P))
	{
		for(int i=0; i<size; i++)
		{
			if(T[i].identique(P))
			{
				size--;
				for(int j=i; j<size; j++)
				{
				T[j]=T[j++];
				}
				return true;
			}
		}
	}
	return false
}








